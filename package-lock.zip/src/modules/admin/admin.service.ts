import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { buildPaginatedResult } from '../../core/dto/pagination.dto';

@Injectable()
export class AdminService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * GET /admin/overview
   * Returns high-level platform telemetry metrics for Super Admin / Admin console
   */
  async getOverview() {
    const [
      totalUsers,
      totalStudents,
      totalColleges,
      pendingCollegesCount,
      totalPrograms,
      totalEnrollments,
      totalSubmissions,
      pendingColleges,
      recentUsers,
      awaitingSubmissions,
      orderRevenueAgg,
      seatOrderRevenueAgg,
      recentPaidOrders,
      recentPaidSeatOrders,
    ] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.student.count(),
      this.prisma.college.count(),
      this.prisma.college.count({ where: { status: 'pending' } }),
      this.prisma.program.count(),
      this.prisma.enrollment.count(),
      this.prisma.submission.count(),
      this.prisma.college.findMany({
        where: { status: 'pending' },
        include: { country: true },
        take: 10,
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.user.findMany({
        take: 8,
        orderBy: { createdAt: 'desc' },
        include: {
          role: true,
          country: true,
        },
      }),
      this.prisma.submission.findMany({
        take: 10,
        orderBy: { createdAt: 'desc' },
        include: {
          student: {
            include: {
              user: true,
            },
          },
          workspaceTask: {
            include: {
              studentWorkspace: {
                include: {
                  enrollmentProject: {
                    include: {
                      project: true,
                      enrollment: {
                        include: {
                          program: true,
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      }),
      // SQL Aggregate: Total captured orders revenue
      this.prisma.order.aggregate({
        _sum: { amount: true },
        where: { status: 'PAID' },
      }),
      // SQL Aggregate: Total captured B2B seat orders revenue
      this.prisma.seatOrder.aggregate({
        _sum: { amount: true },
        where: { status: 'PAID' },
      }),
      // Time-bounded transactions for 12-month rolling trend
      this.prisma.order.findMany({
        where: {
          status: 'PAID',
          createdAt: { gte: new Date(new Date().getFullYear(), new Date().getMonth() - 11, 1) },
        },
        select: { amount: true, createdAt: true },
      }),
      this.prisma.seatOrder.findMany({
        where: {
          status: 'PAID',
          createdAt: { gte: new Date(new Date().getFullYear(), new Date().getMonth() - 11, 1) },
        },
        select: { amount: true, createdAt: true },
      }),
    ]);

    // Fast SQL Sum of captured platform revenue
    const totalRevenue =
      (Number(orderRevenueAgg._sum.amount) || 0) +
      (Number(seatOrderRevenueAgg._sum.amount) || 0);

    // Generate monthly revenue trend (last 12 months)
    const now = new Date();
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthlyTrend: { label: string; year: number; month: number; amount: number }[] = [];

    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      monthlyTrend.push({
        label: monthNames[d.getMonth()],
        year: d.getFullYear(),
        month: d.getMonth(),
        amount: 0,
      });
    }

    const recentTransactions = [
      ...recentPaidOrders.map((o) => ({ amount: Number(o.amount) || 0, createdAt: new Date(o.createdAt) })),
      ...recentPaidSeatOrders.map((so) => ({ amount: Number(so.amount) || 0, createdAt: new Date(so.createdAt) })),
    ];

    recentTransactions.forEach((tx) => {
      const txYear = tx.createdAt.getFullYear();
      const txMonth = tx.createdAt.getMonth();
      const bucket = monthlyTrend.find((m) => m.year === txYear && m.month === txMonth);
      if (bucket) {
        bucket.amount += tx.amount;
      }
    });

    // Generate yearly revenue trend (past 3 years)
    const currentYear = now.getFullYear();
    const yearlyTrend = [
      { label: String(currentYear - 2), amount: 0 },
      { label: String(currentYear - 1), amount: 0 },
      { label: String(currentYear), amount: 0 },
    ];
    recentTransactions.forEach((tx) => {
      const txYear = tx.createdAt.getFullYear();
      const bucket = yearlyTrend.find((y) => y.label === String(txYear));
      if (bucket) {
        bucket.amount += tx.amount;
      }
    });

    const mappedSubmissions = awaitingSubmissions.map((s) => {
      const studentName = (s.student.firstName || s.student.lastName)
        ? `${s.student.firstName || ''} ${s.student.lastName || ''}`.trim()
        : s.student.user?.email?.split('@')[0] || `Student #${s.studentId}`;
      
      const programTitle = s.workspaceTask?.studentWorkspace?.enrollmentProject?.enrollment?.program?.title || 'Engineering Internship Track';
      const taskTitle = s.workspaceTask?.title || 'Capstone Deliverable';

      return {
        id: s.id,
        studentId: s.studentId,
        studentName,
        programTitle,
        taskTitle,
        status: s.status,
        createdAt: s.createdAt,
      };
    });

    return {
      metrics: {
        totalUsers,
        totalStudents,
        totalColleges,
        pendingCollegesCount,
        totalPrograms,
        totalEnrollments,
        totalSubmissions,
        totalRevenue,
      },
      revenueTrend: {
        monthly: monthlyTrend,
        yearly: yearlyTrend,
      },
      pendingColleges: pendingColleges.map((c) => ({
        id: c.id,
        name: c.name,
        address: c.address,
        countryName: c.country.name,
        status: c.status,
        createdAt: c.createdAt,
      })),
      awaitingSubmissions: mappedSubmissions,
      recentUsers: recentUsers.map((u) => ({
        id: u.id,
        email: u.email,
        phoneNo: u.phoneNo,
        roleName: u.role.name,
        countryName: u.country.name,
        status: u.status,
        createdAt: u.createdAt,
      })),
    };
  }

  /**
   * GET /admin/colleges
   * List all colleges with optional status, search, and pagination filters
   */
  async getColleges(params?: { status?: string; search?: string; page?: number; limit?: number } | string) {
    const status = typeof params === 'string' ? params : params?.status;
    const search = typeof params === 'object' ? params?.search : undefined;
    const page = typeof params === 'object' ? params?.page : undefined;
    const limit = typeof params === 'object' ? params?.limit : undefined;

    const where: any = {};
    if (status) {
      where.status = status;
    }
    if (search && search.trim()) {
      where.OR = [
        { name: { contains: search.trim() } },
        { address: { contains: search.trim() } },
      ];
    }

    if (page !== undefined || limit !== undefined) {
      const pageNum = Math.max(1, Number(page) || 1);
      const limitNum = Math.max(1, Math.min(100, Number(limit) || 20));
      const skip = (pageNum - 1) * limitNum;

      const [total, colleges] = await Promise.all([
        this.prisma.college.count({ where }),
        this.prisma.college.findMany({
          where,
          take: limitNum,
          skip,
          include: {
            country: true,
            _count: {
              select: {
                students: true,
                members: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        }),
      ]);

      const mapped = colleges.map((c) => ({
        id: c.id,
        name: c.name,
        address: c.address,
        countryId: c.countryId,
        countryName: c.country.name,
        currencyCode: c.country.currencyCode,
        status: c.status,
        studentCount: c._count.students,
        memberCount: c._count.members,
        createdAt: c.createdAt,
        updatedAt: c.updatedAt,
      }));

      return buildPaginatedResult(mapped, total, pageNum, limitNum);
    }

    const colleges = await this.prisma.college.findMany({
      where,
      include: {
        country: true,
        _count: {
          select: {
            students: true,
            members: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return colleges.map((c) => ({
      id: c.id,
      name: c.name,
      address: c.address,
      countryId: c.countryId,
      countryName: c.country.name,
      currencyCode: c.country.currencyCode,
      status: c.status,
      studentCount: c._count.students,
      memberCount: c._count.members,
      createdAt: c.createdAt,
      updatedAt: c.updatedAt,
    }));
  }

  /**
   * PATCH /admin/colleges/:id/status
   * Approve, reject, or set pending status for a B2B college institution
   */
  async updateCollegeStatus(id: number, status: string) {
    const college = await this.prisma.college.findUnique({
      where: { id },
    });

    if (!college) {
      throw new NotFoundException(`College ID ${id} not found`);
    }

    const updated = await this.prisma.college.update({
      where: { id },
      data: { status },
      include: { country: true },
    });

    return {
      message: `College '${updated.name}' status updated to '${status}'`,
      college: updated,
    };
  }

  /**
   * GET /admin/colleges/:id
   * Complete 360-degree college dossier with B2B seat purchases, coupon batches,
   * college member coordinators, and enrolled student cohort metrics
   */
  async getCollegeDetail(id: number) {
    const college = await this.prisma.college.findUnique({
      where: { id },
      include: {
        country: true,
        members: {
          include: {
            user: {
              include: {
                role: true,
              },
            },
          },
        },
        seatOrders: {
          include: {
            program: {
              select: { id: true, title: true, slug: true, durationHours: true },
            },
            couponBatch: {
              select: { id: true, batchCode: true, totalCoupons: true },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        couponBatches: {
          include: {
            program: {
              select: { id: true, title: true, slug: true, durationHours: true },
            },
            seatOrder: {
              select: { id: true, amount: true, status: true, invoiceRef: true },
            },
            coupons: {
              include: {
                orders: {
                  include: {
                    student: {
                      select: {
                        userid: true,
                        firstName: true,
                        lastName: true,
                        usn: true,
                        user: { select: { email: true, phoneNo: true } },
                      },
                    },
                  },
                },
              },
              orderBy: { id: 'asc' },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        students: {
          include: {
            user: {
              select: { id: true, email: true, phoneNo: true, status: true, createdAt: true },
            },
            enrollments: {
              include: {
                program: { select: { id: true, title: true, slug: true, durationHours: true } },
                certificate: true,
                _count: { select: { selectedProjects: true } },
              },
            },
            certificates: {
              include: {
                enrollment: {
                  include: {
                    program: { select: { id: true, title: true } },
                  },
                },
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!college) {
      throw new NotFoundException(`College ID ${id} not found.`);
    }

    // Aggregations
    const totalStudents = college.students.length;
    const totalSeatOrders = college.seatOrders.length;
    const totalSeatsPurchased = college.seatOrders.reduce((sum, so) => sum + (so.seatsPurchased || 0), 0);
    const totalSeatsRedeemed = college.seatOrders.reduce((sum, so) => sum + (so.seatsRedeemed || 0), 0);
    const totalB2BRevenue = college.seatOrders
      .filter((so) => so.status === 'PAID')
      .reduce((sum, so) => sum + Number(so.amount || 0), 0);
    const totalCouponBatches = college.couponBatches.length;

    // Collect all unique certificates across all students of this college
    const allCertificates = college.students.flatMap((s) => s.certificates);
    const totalCertificatesIssued = allCertificates.length;

    const allEnrollments = college.students.flatMap((s) => s.enrollments);
    const activeEnrollments = allEnrollments.filter((e) => e.status === 'ACTIVE').length;
    const completedEnrollments = allEnrollments.filter((e) => e.status === 'COMPLETED').length;

    return {
      college: {
        id: college.id,
        name: college.name,
        address: college.address,
        status: college.status,
        countryId: college.countryId,
        country: college.country,
        createdAt: college.createdAt,
        updatedAt: college.updatedAt,
      },
      members: college.members.map((m) => ({
        userId: m.userId,
        email: m.user.email,
        phoneNo: m.user.phoneNo,
        status: m.user.status,
        roleName: m.user.role?.name || 'college',
        joinedAt: m.createdAt,
      })),
      seatOrders: college.seatOrders,
      couponBatches: college.couponBatches,
      students: college.students.map((s) => ({
        id: s.userid,
        userId: s.userid,
        name: `${s.firstName} ${s.lastName}`.trim(),
        firstName: s.firstName,
        lastName: s.lastName,
        usn: s.usn,
        branch: s.branch,
        graduationYear: s.graduationYear,
        email: s.user?.email || 'N/A',
        phoneNo: s.user?.phoneNo || 'N/A',
        status: s.user?.status || 'active',
        enrollmentCount: s.enrollments.length,
        enrollments: s.enrollments,
        certificates: s.certificates,
        createdAt: s.createdAt,
      })),
      certificates: allCertificates,
      metrics: {
        totalStudents,
        totalSeatOrders,
        totalSeatsPurchased,
        totalSeatsRedeemed,
        seatUtilizationRate: totalSeatsPurchased > 0 ? Math.round((totalSeatsRedeemed / totalSeatsPurchased) * 100) : 0,
        totalB2BRevenue,
        totalCouponBatches,
        totalCertificatesIssued,
        activeEnrollments,
        completedEnrollments,
      },
    };
  }

  /**
   * GET /admin/users
   * List platform users with optional role, status, search, and pagination filters
   */
  async getUsers(params?: { role?: string; status?: string; search?: string; page?: number; limit?: number } | string, legacyStatus?: string) {
    const role = typeof params === 'string' ? params : params?.role;
    const status = typeof params === 'string' ? legacyStatus : params?.status;
    const search = typeof params === 'object' ? params?.search : undefined;
    const page = typeof params === 'object' ? params?.page : undefined;
    const limit = typeof params === 'object' ? params?.limit : undefined;

    const where: any = {};
    if (status) {
      where.status = status;
    }
    if (role) {
      where.role = { name: role };
    }
    if (search && search.trim()) {
      where.OR = [
        { email: { contains: search.trim() } },
        { phoneNo: { contains: search.trim() } },
        { student: { firstName: { contains: search.trim() } } },
        { student: { lastName: { contains: search.trim() } } },
      ];
    }

    if (page !== undefined || limit !== undefined) {
      const pageNum = Math.max(1, Number(page) || 1);
      const limitNum = Math.max(1, Math.min(100, Number(limit) || 20));
      const skip = (pageNum - 1) * limitNum;

      const [total, users] = await Promise.all([
        this.prisma.user.count({ where }),
        this.prisma.user.findMany({
          where,
          take: limitNum,
          skip,
          include: {
            role: true,
            country: true,
            student: {
              include: { college: true },
            },
            collegeMembers: {
              include: { college: true },
            },
          },
          orderBy: { createdAt: 'desc' },
        }),
      ]);

      const mapped = users.map((u) => {
        const studentName = u.student ? `${u.student.firstName} ${u.student.lastName}`.trim() : null;
        const collegeName = u.student?.college?.name || u.collegeMembers?.[0]?.college?.name || null;
        const collegeId = u.collegeMembers?.[0]?.collegeId || (u.role?.name?.toLowerCase() === 'college' ? u.student?.collegeId : null);

        return {
          id: u.id,
          email: u.email,
          phoneNo: u.phoneNo,
          roleName: u.role.name,
          countryName: u.country.name,
          status: u.status,
          displayName: studentName || collegeName || u.email.split('@')[0],
          collegeName,
          collegeId,
          studentId: u.student ? u.id : null,
          createdAt: u.createdAt,
        };
      });

      return buildPaginatedResult(mapped, total, pageNum, limitNum);
    }

    const users = await this.prisma.user.findMany({
      where,
      include: {
        role: true,
        country: true,
        student: {
          include: { college: true },
        },
        collegeMembers: {
          include: { college: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return users.map((u) => {
      const studentName = u.student ? `${u.student.firstName} ${u.student.lastName}`.trim() : null;
      const collegeName = u.student?.college?.name || u.collegeMembers?.[0]?.college?.name || null;
      const collegeId = u.collegeMembers?.[0]?.collegeId || (u.role?.name?.toLowerCase() === 'college' ? u.student?.collegeId : null);

      return {
        id: u.id,
        email: u.email,
        phoneNo: u.phoneNo,
        roleName: u.role.name,
        countryName: u.country.name,
        status: u.status,
        displayName: studentName || collegeName || u.email.split('@')[0],
        collegeName,
        collegeId,
        studentId: u.student ? u.id : null,
        createdAt: u.createdAt,
      };
    });
  }

  /**
   * GET /admin/students
   * List registered students with college and enrollment metrics + optional pagination
   */
  async getStudents(params?: { collegeId?: number; search?: string; page?: number; limit?: number }) {
    const where: any = {};
    if (params?.collegeId) {
      where.collegeId = params.collegeId;
    }
    if (params?.search && params.search.trim()) {
      const q = params.search.trim();
      where.OR = [
        { firstName: { contains: q } },
        { lastName: { contains: q } },
        { usn: { contains: q } },
        { branch: { contains: q } },
        { customCollegeName: { contains: q } },
        { user: { email: { contains: q } } },
      ];
    }

    if (params?.page !== undefined || params?.limit !== undefined) {
      const pageNum = Math.max(1, Number(params.page) || 1);
      const limitNum = Math.max(1, Math.min(100, Number(params.limit) || 20));
      const skip = (pageNum - 1) * limitNum;

      const [total, students] = await Promise.all([
        this.prisma.student.count({ where }),
        this.prisma.student.findMany({
          where,
          take: limitNum,
          skip,
          include: {
            user: {
              include: {
                country: true,
              },
            },
            college: {
              select: { id: true, name: true },
            },
            _count: {
              select: {
                enrollments: true,
                submissions: true,
                certificates: true,
                orders: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        }),
      ]);

      const mapped = students.map((s) => ({
        id: s.userid,
        userId: s.userid,
        firstName: s.firstName,
        lastName: s.lastName,
        name: `${s.firstName} ${s.lastName}`.trim(),
        email: s.user?.email || 'N/A',
        phoneNo: s.user?.phoneNo || 'N/A',
        countryName: s.user?.country?.name || 'India',
        status: s.user?.status || 'active',
        usn: s.usn,
        branch: s.branch,
        graduationYear: s.graduationYear,
        customCollegeName: s.customCollegeName,
        collegeId: s.collegeId,
        collegeName: s.college?.name || s.customCollegeName || 'N/A',
        enrollmentCount: s._count.enrollments,
        submissionCount: s._count.submissions,
        certificateCount: s._count.certificates,
        orderCount: s._count.orders,
        createdAt: s.createdAt,
      }));

      return buildPaginatedResult(mapped, total, pageNum, limitNum);
    }

    const students = await this.prisma.student.findMany({
      where,
      include: {
        user: {
          include: {
            country: true,
          },
        },
        college: {
          select: { id: true, name: true },
        },
        _count: {
          select: {
            enrollments: true,
            submissions: true,
            certificates: true,
            orders: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return students.map((s) => ({
      id: s.userid,
      userId: s.userid,
      firstName: s.firstName,
      lastName: s.lastName,
      name: `${s.firstName} ${s.lastName}`.trim(),
      email: s.user?.email || 'N/A',
      phoneNo: s.user?.phoneNo || 'N/A',
      countryName: s.user?.country?.name || 'India',
      status: s.user?.status || 'active',
      usn: s.usn,
      branch: s.branch,
      graduationYear: s.graduationYear,
      customCollegeName: s.customCollegeName,
      collegeId: s.collegeId,
      collegeName: s.college?.name || s.customCollegeName || 'N/A',
      enrollmentCount: s._count.enrollments,
      submissionCount: s._count.submissions,
      certificateCount: s._count.certificates,
      orderCount: s._count.orders,
      createdAt: s.createdAt,
    }));
  }

  /**
   * PATCH /admin/users/:id/status
   * Change user status (active, pending, disabled)
   */
  async updateUserStatus(id: number, status: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
    });

    if (!user) {
      throw new NotFoundException(`User ID ${id} not found`);
    }

    const updated = await this.prisma.user.update({
      where: { id },
      data: { status },
      include: { role: true },
    });

    return {
      message: `User status updated to '${status}'`,
      user: {
        id: updated.id,
        email: updated.email,
        status: updated.status,
        roleName: updated.role.name,
      },
    };
  }

  /**
   * GET /admin/submissions
   * Returns list of submissions with optional status, search, and pagination filters
   */
  async getSubmissions(params?: { status?: string; search?: string; page?: number; limit?: number }) {
    const where: any = {};
    if (params?.status && params.status !== 'all') {
      where.status = params.status;
    }
    if (params?.search && params.search.trim()) {
      const q = params.search.trim();
      where.OR = [
        { student: { firstName: { contains: q } } },
        { student: { lastName: { contains: q } } },
        { student: { user: { email: { contains: q } } } },
        { workspaceTask: { title: { contains: q } } },
      ];
    }

    if (params?.page !== undefined || params?.limit !== undefined) {
      const pageNum = Math.max(1, Number(params.page) || 1);
      const limitNum = Math.max(1, Math.min(100, Number(params.limit) || 20));
      const skip = (pageNum - 1) * limitNum;

      const [total, submissions] = await Promise.all([
        this.prisma.submission.count({ where }),
        this.prisma.submission.findMany({
          where,
          take: limitNum,
          skip,
          include: {
            student: {
              include: {
                user: true,
              },
            },
            workspaceTask: {
              include: {
                studentWorkspace: {
                  include: {
                    enrollmentProject: {
                      include: {
                        project: true,
                      },
                    },
                  },
                },
                templateTask: {
                  include: {
                    rubric: true,
                  },
                },
              },
            },
            aiReview: true,
          },
          orderBy: { createdAt: 'desc' },
        }),
      ]);

      const mapped = submissions.map((s) => {
        const studentName = (s.student.firstName || s.student.lastName)
          ? `${s.student.firstName || ''} ${s.student.lastName || ''}`.trim()
          : s.student.user?.email?.split('@')[0] || `Student #${s.studentId}`;

        const rubric = s.workspaceTask?.templateTask?.rubric;
        const maxScore = rubric?.maxScore ?? s.aiReview?.maxScore ?? 100;
        const passThreshold = rubric?.passThreshold ?? 60;

        let criteria: any[] = [];
        if (rubric?.criteria) {
          if (typeof rubric.criteria === 'string') {
            try {
              criteria = JSON.parse(rubric.criteria);
            } catch {
              criteria = [];
            }
          } else if (Array.isArray(rubric.criteria)) {
            criteria = rubric.criteria as any[];
          }
        }

        return {
          id: s.id,
          studentId: s.studentId,
          studentName,
          studentEmail: s.student.user?.email || 'N/A',
          projectTitle: s.workspaceTask?.studentWorkspace?.enrollmentProject?.project?.title || 'Capstone Project',
          taskTitle: s.workspaceTask?.templateTask?.title || s.workspaceTask?.title || 'Deliverable Task',
          commitHash: s.commitHash ?? null,
          repoUrl: s.workspaceTask?.studentWorkspace?.repoUrl ?? null,
          payloadUrl: s.payloadUrl,
          status: s.status,
          submittedAt: s.createdAt,
          workspaceTaskId: s.workspaceTaskId,
          score: s.aiReview?.score ?? null,
          feedback: s.aiReview?.feedback ?? null,
          maxScore,
          passThreshold,
          criteria,
          attemptIndex: s.attemptIndex,
          createdAt: s.createdAt,
        };
      });

      return buildPaginatedResult(mapped, total, pageNum, limitNum);
    }

    const submissions = await this.prisma.submission.findMany({
      where,
      include: {
        student: {
          include: {
            user: true,
          },
        },
        workspaceTask: {
          include: {
            studentWorkspace: {
              include: {
                enrollmentProject: {
                  include: {
                    project: true,
                  },
                },
              },
            },
            templateTask: {
              include: {
                rubric: true,
              },
            },
          },
        },
        aiReview: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return submissions.map((s) => {
      const studentName = (s.student.firstName || s.student.lastName)
        ? `${s.student.firstName || ''} ${s.student.lastName || ''}`.trim()
        : s.student.user?.email?.split('@')[0] || `Student #${s.studentId}`;

      const rubric = s.workspaceTask?.templateTask?.rubric;
      const maxScore = rubric?.maxScore ?? s.aiReview?.maxScore ?? 100;
      const passThreshold = rubric?.passThreshold ?? 60;

      let criteria: any[] = [];
      if (rubric?.criteria) {
        if (typeof rubric.criteria === 'string') {
          try {
            criteria = JSON.parse(rubric.criteria);
          } catch {
            criteria = [];
          }
        } else if (Array.isArray(rubric.criteria)) {
          criteria = rubric.criteria as any[];
        }
      }

      return {
        id: s.id,
        studentId: s.studentId,
        studentName,
        studentEmail: s.student.user?.email || 'N/A',
        projectTitle: s.workspaceTask?.studentWorkspace?.enrollmentProject?.project?.title || 'Capstone Project',
        taskTitle: s.workspaceTask?.templateTask?.title || s.workspaceTask?.title || 'Deliverable Task',
        commitHash: s.commitHash ?? null,
        repoUrl: s.workspaceTask?.studentWorkspace?.repoUrl ?? null,
        payloadUrl: s.payloadUrl,
        status: s.status,
        submittedAt: s.createdAt,
        workspaceTaskId: s.workspaceTaskId,
        score: s.aiReview?.score ?? null,
        feedback: s.aiReview?.feedback ?? null,
        maxScore,
        passThreshold,
        criteria,
        attemptIndex: s.attemptIndex,
        createdAt: s.createdAt,
      };
    });
  }

  /**
   * PATCH /admin/submissions/:id/review
   * Approve or reject a student submission
   */
  async reviewSubmission(id: number, status: 'PASSED' | 'NEEDS_WORK' | 'EVALUATING', score: number, feedback: string) {
    const submission = await this.prisma.submission.findUnique({
      where: { id },
      include: {
        workspaceTask: {
          include: {
            studentWorkspace: {
              include: {
                enrollmentProject: true,
              },
            },
            templateTask: {
              include: {
                rubric: true,
              },
            },
            progress: true,
          },
        },
        aiReview: true,
      },
    });

    if (!submission) {
      throw new NotFoundException(`Submission ID ${id} not found`);
    }

    const rubric = submission.workspaceTask?.templateTask?.rubric;
    const maxScore = rubric?.maxScore ?? 100;
    const passThreshold = rubric?.passThreshold ?? 60;
    const clampedScore = Math.max(0, Math.min(score, maxScore));

    // 1. Update submission status
    const updatedSub = await this.prisma.submission.update({
      where: { id },
      data: { status },
    });

    if (status === 'EVALUATING') {
      await this.prisma.taskProgress.upsert({
        where: { workspaceTaskId: submission.workspaceTaskId },
        update: {
          status: 'OPEN',
          passedAt: null,
        },
        create: {
          workspaceTaskId: submission.workspaceTaskId,
          status: 'OPEN',
        },
      });
      return { success: true, submission: updatedSub };
    }

    // 2. Create AI review / manual review entry
    const passed = status === 'PASSED';
    await this.prisma.aiReview.upsert({
      where: { submissionId: id },
      update: {
        score: clampedScore,
        maxScore,
        passed,
        feedback,
      },
      create: {
        submissionId: id,
        score: clampedScore,
        maxScore,
        passed,
        criteriaBreakdown: rubric?.criteria
          ? (typeof rubric.criteria === 'string' ? rubric.criteria : JSON.stringify(rubric.criteria))
          : JSON.stringify([
              { criterion: 'Manual Verification', score: clampedScore, maxScore },
            ]),
        feedback,
      },
    });

    // 3. Update task progress status
    await this.prisma.taskProgress.upsert({
      where: { workspaceTaskId: submission.workspaceTaskId },
      update: {
        status: passed ? 'PASSED' : 'NEEDS_WORK',
        passedAt: passed ? new Date() : null,
      },
      create: {
        workspaceTaskId: submission.workspaceTaskId,
        status: passed ? 'PASSED' : 'NEEDS_WORK',
        passedAt: passed ? new Date() : null,
      },
    });

    // 4. Advance progress if passed (Unlock next task or project)
    if (passed) {
      const task = submission.workspaceTask;
      const studentWorkspaceId = task.studentWorkspaceId;
      const currentOrderIndex = task.orderIndex;

      // Find next task in current workspace
      const nextTask = await this.prisma.workspaceTask.findFirst({
        where: {
          studentWorkspaceId,
          orderIndex: { gt: currentOrderIndex },
        },
        orderBy: { orderIndex: 'asc' },
      });

      if (nextTask) {
        // Unlock next task in DB
        await this.prisma.taskProgress.upsert({
          where: { workspaceTaskId: nextTask.id },
          update: { status: 'OPEN', unlockedAt: new Date() },
          create: { workspaceTaskId: nextTask.id, status: 'OPEN', unlockedAt: new Date() },
        });
      } else {
        // All tasks in this project passed -> mark EnrollmentProject as DONE
        const currentEpId = task.studentWorkspace.enrollmentProjectId;
        const currentEnrollmentId = task.studentWorkspace.enrollmentProject.enrollmentId;
        const currentProjectOrder = task.studentWorkspace.enrollmentProject.orderIndex;

        await this.prisma.enrollmentProject.update({
          where: { id: currentEpId },
          data: { status: 'DONE' },
        });

        // Unlock next EnrollmentProject as ACTIVE
        const nextEp = await this.prisma.enrollmentProject.findFirst({
          where: {
            enrollmentId: currentEnrollmentId,
            orderIndex: { gt: currentProjectOrder },
          },
          orderBy: { orderIndex: 'asc' },
          include: {
            workspace: {
              include: {
                tasks: { orderBy: { orderIndex: 'asc' }, take: 1 },
              },
            },
          },
        });

        if (nextEp) {
          await this.prisma.enrollmentProject.update({
            where: { id: nextEp.id },
            data: { status: 'ACTIVE' },
          });

          // Unlock 1st task of next project
          const nextProjFirstTask = nextEp.workspace?.tasks?.[0];
          if (nextProjFirstTask) {
            await this.prisma.taskProgress.upsert({
              where: { workspaceTaskId: nextProjFirstTask.id },
              update: { status: 'OPEN', unlockedAt: new Date() },
              create: { workspaceTaskId: nextProjFirstTask.id, status: 'OPEN', unlockedAt: new Date() },
            });
          }
        }
      }
    }

    return {
      message: `Submission ${id} reviewed successfully. Status updated to ${status}.`,
      submission: updatedSub,
    };
  }

  /**
   * GET /admin/students/:id
   * Complete 360-degree student portfolio, academic profile, enrollment tracks,
   * workspace step progression, billing/orders reconciliation, and certificates
   */
  async getStudentDetail(id: number) {
    const student = await this.prisma.student.findFirst({
      where: {
        OR: [{ userid: id }],
      },
      include: {
        user: {
          include: {
            role: true,
            country: true,
          },
        },
        college: {
          include: {
            country: true,
          },
        },
        enrollments: {
          include: {
            program: {
              include: {
                country: true,
              },
            },
            order: {
              include: {
                coupon: {
                  include: {
                    batch: {
                      include: {
                        college: true,
                      },
                    },
                  },
                },
                payments: {
                  orderBy: { createdAt: 'desc' },
                },
              },
            },
            certificate: true,
            selectedProjects: {
              include: {
                project: true,
                workspace: {
                  include: {
                    tasks: {
                      include: {
                        progress: true,
                        submissions: {
                          include: {
                            aiReview: true,
                          },
                          orderBy: { createdAt: 'desc' },
                        },
                      },
                      orderBy: { orderIndex: 'asc' },
                    },
                  },
                },
              },
              orderBy: { orderIndex: 'asc' },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        orders: {
          include: {
            program: {
              select: { id: true, title: true, slug: true, durationHours: true },
            },
            coupon: {
              select: {
                id: true,
                code: true,
                status: true,
                batch: {
                  select: {
                    id: true,
                    batchCode: true,
                    college: { select: { id: true, name: true } },
                  },
                },
              },
            },
            payments: {
              orderBy: { createdAt: 'desc' },
            },
            enrollment: {
              select: { id: true, status: true, enrolledAt: true, completedAt: true },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        certificates: {
          include: {
            enrollment: {
              include: {
                program: {
                  select: { id: true, title: true, slug: true, durationHours: true },
                },
              },
            },
          },
          orderBy: { issuedAt: 'desc' },
        },
        submissions: {
          include: {
            workspaceTask: {
              include: {
                studentWorkspace: {
                  include: {
                    enrollmentProject: {
                      include: {
                        project: { select: { id: true, title: true } },
                        enrollment: {
                          include: {
                            program: { select: { id: true, title: true } },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
            aiReview: true,
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!student) {
      // Fallback: Check if user exists but student record not yet initialized
      const user = await this.prisma.user.findUnique({
        where: { id },
        include: {
          role: true,
          country: true,
          student: true,
        },
      });

      if (!user) {
        throw new NotFoundException(`Student or User with ID ${id} not found.`);
      }

      return {
        user: {
          id: user.id,
          email: user.email,
          phoneNo: user.phoneNo,
          status: user.status,
          role: user.role,
          country: user.country,
          createdAt: user.createdAt,
          updatedAt: user.updatedAt,
        },
        student: null,
        enrollments: [],
        orders: [],
        certificates: [],
        submissions: [],
        metrics: {
          totalEnrollments: 0,
          activeEnrollments: 0,
          completedEnrollments: 0,
          totalOrders: 0,
          totalSpent: 0,
          totalSubmissions: 0,
          passedSubmissions: 0,
          averageScore: 0,
          totalCertificates: 0,
        },
      };
    }

    // Compute Metrics & Aggregations
    const totalEnrollments = student.enrollments.length;
    const completedEnrollments = student.enrollments.filter((e) => e.status === 'COMPLETED').length;
    const activeEnrollments = student.enrollments.filter((e) => e.status === 'ACTIVE').length;
    const totalOrders = student.orders.length;
    const totalSpent = student.orders
      .filter((o) => o.status === 'PAID')
      .reduce((sum, o) => sum + Number(o.amount || 0), 0);
    const totalSubmissions = student.submissions.length;
    const passedSubmissions = student.submissions.filter((s) => s.status === 'PASSED').length;

    const scores = student.submissions
      .map((s) => s.aiReview?.score)
      .filter((score): score is number => typeof score === 'number' && score >= 0);
    const averageScore = scores.length > 0
      ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length)
      : 0;
    const totalCertificates = student.certificates.length;

    return {
      user: {
        id: student.user.id,
        email: student.user.email,
        phoneNo: student.user.phoneNo,
        status: student.user.status,
        role: student.user.role,
        country: student.user.country,
        createdAt: student.user.createdAt,
        updatedAt: student.user.updatedAt,
      },
      student: {
        userId: student.userid,
        firstName: student.firstName,
        lastName: student.lastName,
        fullName: `${student.firstName} ${student.lastName}`.trim(),
        usn: student.usn,
        branch: student.branch,
        graduationYear: student.graduationYear,
        customCollegeName: student.customCollegeName,
        collegeId: student.collegeId,
        college: student.college,
        createdAt: student.createdAt,
        updatedAt: student.updatedAt,
      },
      enrollments: student.enrollments,
      orders: student.orders,
      certificates: student.certificates,
      submissions: student.submissions,
      metrics: {
        totalEnrollments,
        activeEnrollments,
        completedEnrollments,
        totalOrders,
        totalSpent,
        totalSubmissions,
        passedSubmissions,
        averageScore,
        totalCertificates,
      },
    };
  }
}
